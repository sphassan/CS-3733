#define OS -2
#define NONE -1

int* initializeFrames(int** frames, int size);
int findOpen(int** frames, int size);
int* reverseMap(int** frames, int frame, int page);
