Compile with: javac assign5.java CPU.java FileRead.java IO.java OS.java PCB.java
Execute with: java assign5 -alg [FIFO|SJF|PR|RR] [-quantum [integer(ms)]] -input [file name] [-debug]
