void part0(char *s1, char *s2);
void display(char *heading, char *s1, char *s2);
void fcfsa(char *s1, char *s2, int x1, int y1, int z1, int x2, int y2, int z2);
